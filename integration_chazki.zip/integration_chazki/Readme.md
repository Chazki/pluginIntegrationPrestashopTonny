# Plugin Chazki para Prestashop
Plugin de Prestashop 1.7.8 de Chazki para la integración con Nintendo
